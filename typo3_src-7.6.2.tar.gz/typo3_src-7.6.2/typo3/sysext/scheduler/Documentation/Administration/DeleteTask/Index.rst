﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt



.. _deleting-a-task:

Deleting a task
^^^^^^^^^^^^^^^

When choosing to delete a task, a pop-up window will appear requesting
confirmation. If confirmed, the deletion is final. There is no
"deleted" flag in the Scheduler's table, deleted task registrations
cannot be recovered.

