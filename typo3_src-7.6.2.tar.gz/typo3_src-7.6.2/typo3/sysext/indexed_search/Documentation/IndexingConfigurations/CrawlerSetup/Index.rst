﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt



.. _crawler-setup:

Setting up the "crawler" extension
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Before you can work with "Indexing configurations" you must make sure
you have set up the "crawler" extension and have a cron-job running
that will process the crawler queue as we fill it! For this, please
refer to the documentation of the "crawler" extension!

